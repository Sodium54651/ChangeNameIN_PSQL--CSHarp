﻿using System;
using System.Windows.Forms;
using Npgsql;

namespace ChageNameInTabe
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }









        //В ТВОЕЙ БАЗЕ ДАННЫХ ВСЕ БУКОВКИ ДОЛЖНЫ БЫТЬ НА ЛАТИНИЦЕ И С МАЛЕНЬКЙО БУКОВОКОВКИ
        private (int id, string a) selectit(string oldname)
        {
            //выбираешь к какой бд подключаться
            string connString = "Host=localhost;Port=5432;Username=postgres;Password=a;Database=Rae_NameRate";
            //создаёшь переменную с классом подключения к вон той базе данных
            using (var rh = new NpgsqlConnection(connString))
            {
                rh.Open();

                //делаешь запросик 
                string sql = "SELECT id_user, name, password FROM users WHERE name=@name";
                //обращаешся с вот таким запросок к вон той базе данных
                using (var cmd = new NpgsqlCommand(sql, rh))
                {
                    //делаем инкапсуляцию или защиту от неё
                    cmd.Parameters.AddWithValue("name", oldname);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            int dbID = Convert.ToInt32(reader["ID_User"]);
                            string dbPass = reader["password"].ToString();
                            MessageBox.Show(dbPass.ToString() + " "+ dbID.ToString());
                            return(dbID, dbPass);
                        }
                        else
                        {
                            return (-1 , "");
                        }
                    }
                }
            }
        }



        private void changename(string oldname, string oldpass, string newname, string newpass)
        {
            //выбираешь к какой бд подключаться
            string connString = "Host=localhost;Port=5432;Username=postgres;Password=a;Database=Rae_NameRate";
            //создаёшь переменную с классом подключения к вон той базе данных
            using (var rh = new NpgsqlConnection(connString))
            {
                rh.Open();

                (int id, string bdpass) = selectit(oldname);

                if (id == -1)
                    MessageBox.Show("⚠️Пользователя нет в системе");
                else
                {
                    string sql = "UPDATE users SET name = @name, password = @pass WHERE id_user = @id";
                    using (var cmd = new NpgsqlCommand(sql, rh))
                    {
                        cmd.Parameters.AddWithValue("id", id);
                        cmd.Parameters.AddWithValue("name", newname);
                        cmd.Parameters.AddWithValue("pass", newpass);

                        //эта штука проверяет сколько строк было изменено
                        //возвращает колличетсво изм. строк. иначе -1 если нельзя изм.
                        if (cmd.ExecuteNonQuery() > 0)
                        {
                            MessageBox.Show("✅Данные были успешно обновлены");

                            olduser.Text = "";
                            oldpassword.Text = "";
                            newuser.Text = "";
                            newpassword.Text = null;
                        }
                        else
                        {
                            MessageBox.Show("🛑Данные не были обновлены");
                        }
                    }
                }
                
            }
        }





        private void button1_Click(object sender, EventArgs e)
        {
            if (olduser.Text == "" && oldpassword.Text == "")
            {
                MessageBox.Show("⚠️Ты не ввел ничего");
                return;
            }

            string oldname = olduser.Text;
            string oldpass = oldpassword.Text;

            string newname = newuser.Text;
            string newpass = newpassword.Text;

            //selectit(oldname);

            changename(oldname, oldpass, newname, newpass);

        }
    }
}
