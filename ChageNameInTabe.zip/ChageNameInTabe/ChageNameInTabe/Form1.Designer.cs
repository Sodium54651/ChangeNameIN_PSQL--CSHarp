﻿namespace ChageNameInTabe
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.user = new System.Windows.Forms.Label();
            this.olduser = new System.Windows.Forms.RichTextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.oldpassword = new System.Windows.Forms.RichTextBox();
            this.newpassword = new System.Windows.Forms.RichTextBox();
            this.newuser = new System.Windows.Forms.RichTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(119)))), ((int)(((byte)(185)))), ((int)(((byte)(237)))));
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.newpassword);
            this.panel1.Controls.Add(this.newuser);
            this.panel1.Controls.Add(this.oldpassword);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.user);
            this.panel1.Controls.Add(this.olduser);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(776, 544);
            this.panel1.TabIndex = 1;
            // 
            // user
            // 
            this.user.AutoSize = true;
            this.user.Font = new System.Drawing.Font("Verdana", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.user.ForeColor = System.Drawing.Color.Black;
            this.user.Location = new System.Drawing.Point(12, 161);
            this.user.Name = "user";
            this.user.Size = new System.Drawing.Size(352, 28);
            this.user.TabIndex = 8;
            this.user.Text = "заменить пользователя...";
            // 
            // olduser
            // 
            this.olduser.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.olduser.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.olduser.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.olduser.Location = new System.Drawing.Point(446, 140);
            this.olduser.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.olduser.Name = "olduser";
            this.olduser.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.olduser.Size = new System.Drawing.Size(302, 55);
            this.olduser.TabIndex = 7;
            this.olduser.Text = "";
            this.olduser.WordWrap = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(52)))), ((int)(((byte)(81)))), ((int)(((byte)(103)))));
            this.panel2.Controls.Add(this.label1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.ForeColor = System.Drawing.Color.White;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(776, 126);
            this.panel2.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(776, 126);
            this.label1.TabIndex = 0;
            this.label1.Text = "Меняем Имя пользователя в системе";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(13, 246);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(351, 28);
            this.label2.TabIndex = 9;
            this.label2.Text = "пароль подтверждения...";
            // 
            // oldpassword
            // 
            this.oldpassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.oldpassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.oldpassword.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.oldpassword.Location = new System.Drawing.Point(446, 225);
            this.oldpassword.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.oldpassword.Name = "oldpassword";
            this.oldpassword.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.oldpassword.Size = new System.Drawing.Size(302, 55);
            this.oldpassword.TabIndex = 10;
            this.oldpassword.Text = "";
            this.oldpassword.WordWrap = false;
            // 
            // newpassword
            // 
            this.newpassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.newpassword.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.newpassword.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.newpassword.Location = new System.Drawing.Point(446, 402);
            this.newpassword.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.newpassword.Name = "newpassword";
            this.newpassword.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.newpassword.Size = new System.Drawing.Size(302, 55);
            this.newpassword.TabIndex = 12;
            this.newpassword.Text = "";
            this.newpassword.WordWrap = false;
            // 
            // newuser
            // 
            this.newuser.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.newuser.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.newuser.Font = new System.Drawing.Font("Verdana", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.newuser.Location = new System.Drawing.Point(446, 317);
            this.newuser.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.newuser.Name = "newuser";
            this.newuser.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.None;
            this.newuser.Size = new System.Drawing.Size(302, 55);
            this.newuser.TabIndex = 11;
            this.newuser.Text = "";
            this.newuser.WordWrap = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Verdana", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(12, 423);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(303, 28);
            this.label3.TabIndex = 14;
            this.label3.Text = "заменить пароль на...";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Verdana", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(11, 338);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(260, 28);
            this.label4.TabIndex = 13;
            this.label4.Text = "заменить имя на...\r\n";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Verdana", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(266, 479);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(255, 53);
            this.button1.TabIndex = 15;
            this.button1.Text = "🔄️Замена";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(776, 544);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(794, 591);
            this.MinimumSize = new System.Drawing.Size(794, 591);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RichTextBox olduser;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label user;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RichTextBox newpassword;
        private System.Windows.Forms.RichTextBox newuser;
        private System.Windows.Forms.RichTextBox oldpassword;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
    }
}

